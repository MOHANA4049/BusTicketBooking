import React from "react";
import { Card } from "@material-ui/core";
import { Grid } from "@mui/material";
import Typography from "@material-ui/core/Typography";
import CardActionArea from "@mui/material/CardActionArea";
import CardActions from "@material-ui/core/CardActions";
import CardContent from "@material-ui/core/CardContent";
import CardMedia from "@material-ui/core/CardMedia";
import Button from "@material-ui/core/Button";
import { Link } from "react-router-dom";
import Navbar from './navbar';
import './bus.css';
// import Link from "@material-ui/core";
function Buses(props)
{
  const posts=[
    {
      Source:"Salem",
      Destination:"Coimbatore",
      src:require('./images/b5.jpeg'),
      Description:"Jihan luxury travels",
      Tickets:"40",
      fare:"500",
      Time:"2:30pm",
    },
    {
      Source:"Chennai",
      Destination:"Coimbatore",
      src:require('./images/bus2.jpeg'),
      Description:"SR Tours and Travels",
      Tickets:"40",
      fare:"520",
      Time:"11:00am",
    },
    {
      Source:"Chennai",
      Destination:"Salem",
      src:require('./images/b2.jpeg'),
      Description:"City Travels",
      Tickets:"40",
      fare:"400",
      Time:"10:00pm",
    },
    {
      Source:"Chennai",
      Destination:"Coimbatore",
      src:require('./images/b4.jpeg'),
      Description:"Maaruthi Travels",
      Tickets:"40",
      fare:"520",
      Time:"9:00am",
    },
    {
      Source:"Chennai",
      Destination:"Coimbatore",
      src:require('./images/bus1.jpeg'),
      Description:"SRL Travels",
      Tickets:"40",
      fare:"520",
      Time:"10:30pm",
    },
    {
      Source:"Chennai",
      Destination:"Coimbatore",
      src:require('./images/tour bus.jpeg'),
      Description:"IntrCity SmartBus",
      Tickets:"40",
      fare:"520",
      Time:"8:00am",
    },
  ]
  return(
    <div className="mat">
    <Navbar/>
    <br></br>
    <br></br>
    <Grid style={{ marginTop: 10, padding: 10 }}  container spacing={10} justifyContent="center">
      {posts.map(post => (
        <Grid item key={post.Source} >
          <Card className="hov">
            <CardActionArea>
              <CardMedia 
                component="img"
                alt="Movie"
                height="140"
                width="50"
                image={post.src}
                Source="Source"
                Destination="Destination"
              />
              <CardContent>
                <Typography>{post.Description}      {post.Time}</Typography>
                <Typography>Available Tickets:{post.Tickets} Fare:{post.fare}</Typography>
                <Typography  gutterBottom  component="h2">
                  {post.Source} to {post.Destination}
                </Typography>
                <Link to="/seat"><button className="k">VIEW SEATS</button></Link>
              </CardContent>
            </CardActionArea>
          </Card>
        </Grid>
      ))}
    </Grid>
  </div>
);
}
export default Buses;
