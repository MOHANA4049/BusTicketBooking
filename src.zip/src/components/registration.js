import React from 'react';
// import './reg.css';
import { Link } from 'react-router-dom';
class Registration extends React.Component
{
  constructor() {
    super();
    this.state = { 
      fields: {},   
      errors: {}
    }
    this.handleChange = this.handleChange.bind(this);
    this.submitRegistrationForm = this.submitRegistrationForm.bind(this);
  };

  handleChange(e) {
    let fields = this.state.fields;
    fields[e.target.name] = e.target.value;
    this.setState({
      fields
    });
  

  }

  submitRegistrationForm(e) {
    console.log(this.validateForm());
    
    e.preventDefault();
    if (this.validateForm()) {
        console.log(this.state);
         let fields = {};
         fields["username"] = "";
         fields["gender"] = "";
         fields["mobileno"] = "";
         fields["password"] = "";
        this.setState({fields:fields});
        console.log(this.state);
        alert("Your Form has been submitted successfully.");
    }

  }

  validateForm() {

    let fields = this.state.fields;
    let errors = {};
    let formIsValid = true;

    if (!fields["username"]) {
      formIsValid = false;
      errors["username"] = "*Please enter your username.";
    }
    if (typeof fields["username"] !== "undefined") {
      if (!fields["username"].match(/^[a-zA-Z ]*$/)) {
        formIsValid = false;
        errors["username"] = "*Please enter alphabet characters only.";
      }
    }
    if (!fields["gender"]) {
      formIsValid = false;
      errors["gender"] = "*Please enter your gender.";
    }
    if (!fields["mobileno"]) {
      formIsValid = false;
      errors["mobileno"] = "*Please enter your mobile no.";
    }

    if (typeof fields["mobileno"] !== "undefined") {
      if (!fields["mobileno"].match(/^[0-9]{10}$/)) {
        formIsValid = false;
        errors["mobileno"] = "*Please enter valid mobile no.";
      }
    }

    if (!fields["password"]) {
      formIsValid = false;
      errors["password"] = "*Please enter your password.";
    }

    if (typeof fields["password"] !== "undefined") {
      if (!fields["password"].match(/^[a-zA-z0-9]{8,}$/)) {
        formIsValid = false;
        errors["password"] = "*Please enter secure and strong password.";
      }
    }

    this.setState({
      errors: errors
    });
    return formIsValid;
    
  }

    render()
    {
      return(
  <div className="login-page">
  <div className="form">
    <form className="register-form" onSubmit={this.submitRegistrationForm}>
      <h2 align="center">Registration</h2>
      <input type="text" name="username" placeholder="Username" value={this.state.fields.username} onChange={this.handleChange}/>
      <div className="errorMsg">{this.state.errors.username}</div>
      <input type="text" name="gender" placeholder="Gender"value={this.state.fields.gender} onChange={this.handleChange}/>
      <div className="errorMsg">{this.state.errors.gender}</div>
      <input type="number" name="mobileno" placeholder="MobileNo" value={this.state.fields.mobileno} onChange={this.handleChange}/>
      <div className="errorMsg">{this.state.errors.mobileno}</div>
      <input type="password" name="password" placeholder="password" value={this.state.fields.password}onChange={this.handleChange}/>
      <div className="errorMsg">{this.state.errors.password}</div>
      {/* <Link to="/"> */}
      <button type="submit">Signin</button>
      {/* </Link> */}
      <p className="message">
        Already registered? 
            <Link to="/login">
           Sign In
            </Link>   
      </p>
      <br></br><br></br><br></br>
    </form>
  </div>
   </div>
      );
    }
}
export default Registration;