import React from "react";
import { Card } from "@material-ui/core";
import { Grid } from "@mui/material";
import Typography from "@material-ui/core/Typography";
import CardActionArea from "@mui/material/CardActionArea";
import CardActions from "@material-ui/core/CardActions";
import CardContent from "@material-ui/core/CardContent";
import CardMedia from "@material-ui/core/CardMedia";
function Buses(props)
{
  const posts=[
    {
      Source:"Salem",
      Destination:"Coimbatore",
      src:require('./images/b5.jpeg'),
      Description:"Jihan luxury travels",
      Tickets:"20",
      fare:"500",
    },
    {
      Source:"Chennai",
      Destination:"Coimbatore",
      src:require('./images/bus2.jpeg'),
      Description:"SR Tours and Travels",
      Tickets:"25",
      fare:"520",
    },
    {
      Source:"Chennai",
      Destination:"Salem",
      src:require('./images/b2.jpeg'),
      Description:"City Travels",
      Tickets:"10",
      fare:"400",
    },
    {
      Source:"Chennai",
      Destination:"Coimbatore",
      src:require('./images/bus2.jpeg'),
      Description:"SR Tours and Travels",
      Tickets:"25",
      fare:"520",
    },
    {
      Source:"Chennai",
      Destination:"Coimbatore",
      src:require('./images/bus2.jpeg'),
      Description:"SR Tours and Travels",
      Tickets:"25",
      fare:"520",
    },
    {
      Source:"Chennai",
      Destination:"Coimbatore",
      src:require('./images/bus2.jpeg'),
      Description:"SR Tours and Travels",
      Tickets:"25",
      fare:"520",
    },
  ]
  return(
    <div style={{ marginTop: 20, padding: 30 }} className="Zoom">
    <Grid container spacing={10} justifyContent="center">
      {posts.map(post => (
        <Grid item key={post.Source}>
          <Card>
            <CardActionArea >
              <CardMedia
                component="img"
                alt="Movie"
                height="140"
                image={post.src}
                Source="source"
                Destination="dest"
              />
              <CardContent>
                <Typography>{post.Description}</Typography>
                <Typography>Available Tickets:{post.Tickets} Fare:{post.fare}</Typography>
                <Typography variant="body2" color="text.secondary" gutterBottom  component="h2">
                  {post.Source} to {post.Destination}
                </Typography>
              </CardContent>
            </CardActionArea>
          </Card>
        </Grid>
      ))}
    </Grid>
  </div>
);
}
export default Buses;
