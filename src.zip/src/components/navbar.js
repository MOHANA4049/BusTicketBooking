import React from "react";
import './nav.css';
import { Link } from "react-router-dom";
import { Search } from "@material-ui/icons";
function Navbar(){
    return(
    <div>
     <div className="nav" id="welcome">
     <div id="mySidepanel" class="sidepanel">
       <a href="javascript:void(0)" class="closebtn" onClick={closeNav}>x</a>
       <Link to="/about">About</Link>
       <a>Services</a>
       <a>Clients</a>
       <a>Contact</a>
     </div>
     <button class="openbtn" onClick={openNav}>&#9776;</button>
     <h3>BOOKMYBUS</h3>
     <ul className="list">
            <li className="nav-item">
                <a className="link">
                   PROFILE
                </a>
            </li>
            <li className="nav-item" style={{textDecoration:"none"}}>
                   HELP
            </li>
            <li className="nav-item" style={{textDecoration:"none"}}>
                   <Link to='/login'>LOGIN</Link>
            </li>
            <li className="nav-item">
                <a className="link">
                    <Link to='/registration'>REGISTER</Link>
                </a>
            </li>
        </ul>
    </div>
    <div className="home">
        <div className="box">
        <input type="text" placeholder="Source"></input>
        <input type="text" placeholder="Destination"></input>
        <input type="date"></input>
        <Link to="/buses"><button className="search" type="button">SearchBuses<Search/></button></Link>
        </div>
    </div>
    </div>
    )
       /* Set the width of the sidebar to 250px (show it) */
   function openNav() {
    document.getElementById("mySidepanel").style.width = "250px";
  }
  
  /* Set the width of the sidebar to 0 (hide it) */
  function closeNav() {
    document.getElementById("mySidepanel").style.width = "0";
  }
}
export default Navbar;