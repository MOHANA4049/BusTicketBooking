import logo from './logo.svg';
import './App.css';
import Navbar from './components/navbar';
import ReactDOM from "react-dom/client";
import { Routes, Route } from "react-router-dom";
import Registration from './components/registration';
import About from './components/about';
import Login from './components/login';
import Buses from './components/buses';
function App() {
  return (
    // <div>
    //   <Buses/>
    // </div>
    <Routes>
      <Route path="/"element={<Navbar/>}></Route>
      <Route path="/login"element={<Login/>}/>
      <Route path="/registration"element={<Registration/>}/>
      <Route path="/about" element={<About/>}/>
      <Route path="/buses" element={<Buses/>}></Route>
    </Routes>
  // );
  );
  }
export default App;
