
import * as React from 'react';
import './reg.css';
import { Link,useNavigate} from 'react-router-dom';
import { useState } from 'react';
const Login=()=>
{
  const [username,setUsername]=useState("");
  const [password,setPassword]=useState("");
  const[pw,setPw]=useState("false");
  const navigate=useNavigate();
  const check=()=>{
    if(password=="Mohana@123")
    {
      setPw(true);
        {(pw && (alert('Login Successful.')))}
      {(pw && (navigate('/')))}
    }
  }
  return(
    <div className="login-page1">
    <div className="form">
      <form className="login-form">
        <br></br>
      <h2 align="center">Login</h2>
      <br></br><br></br>
      <input type="text" placeholder="Username"value={username} onChange={(e)=>setUsername(e.target.value)} required/>
      <br></br><br></br>
      <input type="password" placeholder="password" value={password} onChange={(e)=>setPassword(e.target.value)} required/>
      <br></br><br></br>
      <button type="submit" onClick={check}>Login</button>
      <br></br><br></br>
      <p className="message">
        Not registered?
          <Link to="/registration">
          Create an account
        </Link>
      </p>
    </form>
    </div>
    </div>
   
  )
}
export default Login;